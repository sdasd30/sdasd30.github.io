Seven Second Shooter (7SS)

Extract 7SS.zip to any location. Start 7SS.exe to start the game.
If you need help playing the game, How2Play.png gives some simple instructions.

If you have any questions, please do not hesitate to message me on Discord.